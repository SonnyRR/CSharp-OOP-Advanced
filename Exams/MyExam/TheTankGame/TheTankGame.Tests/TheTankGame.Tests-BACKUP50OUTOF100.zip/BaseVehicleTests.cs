﻿namespace TheTankGame.Tests
{
    using NUnit.Framework;
    using System;

    //using TheTankGame.Entities.Miscellaneous;
    //using TheTankGame.Entities.Miscellaneous.Contracts;
    //using TheTankGame.Entities.Vehicles;
    //using TheTankGame.Entities.Vehicles.Contracts;

    [TestFixture]
    public class BaseVehicleTests
    {

        [Test]
        public void ModelShouldThrowException()
        {
            //string vehicleType = arguments[0];
            //string model = arguments[1];
            //double weight = double.Parse(arguments[2]);
            //decimal price = decimal.Parse(arguments[3]);
            //int attack = int.Parse(arguments[4]);
            //int defense = int.Parse(arguments[5]);
            //int hitPoints = int.Parse(arguments[6]);

            IVehicle vehicle;
            IAssembler assembler = new VehicleAssembler();      

            Assert.That(() => vehicle = new Revenger("", 3.3, 3.3m, 3, 3, 3, assembler), Throws.ArgumentException
                .With.Message.EqualTo("Model cannot be null or white space!"));
        }

        [Test]
        public void WeightShouldThrowException()
        {
            //Weight cannot be less or equal to zero!
            IVehicle vehicle;
            IAssembler assembler = new VehicleAssembler();

            Assert.That(() => vehicle = new Revenger("IDK", 0, 3.3m, 3, 3, 3, assembler), Throws.ArgumentException
                .With.Message.EqualTo("Weight cannot be less or equal to zero!"));

            Assert.That(() => vehicle = new Revenger("IDK", -1, 3.3m, 3, 3, 3, assembler), Throws.ArgumentException
                .With.Message.EqualTo("Weight cannot be less or equal to zero!"));
        }

        [Test]
        public void PriceShouldThrowException()
        {
            IVehicle vehicle;
            IAssembler assembler = new VehicleAssembler();

            Assert.That(() => vehicle = new Revenger("IDK", 33, 0m, 3, 3, 3, assembler), Throws.ArgumentException
                .With.Message.EqualTo("Price cannot be less or equal to zero!"));

            Assert.That(() => vehicle = new Revenger("IDK", 33, -1m, 3, 3, 3, assembler), Throws.ArgumentException
                .With.Message.EqualTo("Price cannot be less or equal to zero!"));

        }

        [Test]
        public void AttackShouldThrowException()
        {
            IVehicle vehicle;
            IAssembler assembler = new VehicleAssembler();

            Assert.That(() => vehicle = new Revenger("IDK", 33, 3m, -512, 3, 3, assembler), Throws.ArgumentException
                .With.Message.EqualTo("Attack cannot be less than zero!"));

        }

        [Test]
        public void DefenseShouldThrowException()
        {
            IVehicle vehicle;
            IAssembler assembler = new VehicleAssembler();

            Assert.That(() => vehicle = new Revenger("IDK", 33, 3m, 12, -2, 3, assembler), Throws.ArgumentException
                .With.Message.EqualTo("Defense cannot be less than zero!"));
        }

        [Test]
        public void HitPointsShouldThrowException()
        {
            IVehicle vehicle;
            IAssembler assembler = new VehicleAssembler();

            Assert.That(() => vehicle = new Revenger("IDK", 33, 3m, 12, 2, -3, assembler), Throws.ArgumentException
                .With.Message.EqualTo("HitPoints cannot be less than zero!"));
        }
    }
}