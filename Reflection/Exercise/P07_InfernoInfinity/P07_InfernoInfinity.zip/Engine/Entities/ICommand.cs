﻿namespace P07_InfernoInfinity.Engine.Entities
{
    public interface ICommand
    {
        bool Execute();
    }
}
